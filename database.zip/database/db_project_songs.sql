-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `songs`
--

DROP TABLE IF EXISTS `songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `songs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `artist` varchar(45) DEFAULT NULL,
  `featured` varchar(45) DEFAULT NULL,
  `length` int DEFAULT NULL,
  `playlist_id` int DEFAULT NULL,
  `genre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `songs_to_playlist_idx` (`playlist_id`),
  KEY `songs_to_genre_idx` (`genre`),
  CONSTRAINT `songs_to_genre` FOREIGN KEY (`genre`) REFERENCES `genres` (`name`),
  CONSTRAINT `songs_to_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `songs`
--

LOCK TABLES `songs` WRITE;
/*!40000 ALTER TABLE `songs` DISABLE KEYS */;
INSERT INTO `songs` VALUES (1,'RAPSTAR','Polo G',NULL,165,6,'RAP'),(4,'MONTERO','Lil Nas X',NULL,137,6,'RAP'),(5,'Heartbreak Anniversary','Giveon',NULL,193,1,'POP'),(9,'Save your tears','the weekend',NULL,NULL,19,NULL),(10,'kiss me more','doja cat',NULL,NULL,NULL,NULL),(11,'leave the door open ','bruno mars',NULL,NULL,NULL,NULL),(12,'Astronaut In the Ocean','Masked Wolf',NULL,NULL,NULL,NULL),(13,'Goodbumps','Travis Scott',NULL,NULL,NULL,NULL),(14,'deja vu','Olivia Rodrigo',NULL,NULL,NULL,'POP'),(15,'Hold On','Justin Bieber',NULL,NULL,5,'POP'),(16,'Sweet Child of Mine','Gunz n Roses',NULL,NULL,NULL,'ROCK'),(17,'White Iverson','Post Malone',NULL,NULL,NULL,'POP'),(18,'Thunderstruck','ACDC',NULL,NULL,NULL,'ROCK'),(19,'Rap God','Eminem',NULL,NULL,6,'RAP'),(20,'Violent Crimes','Kanye West',NULL,NULL,NULL,'POP'),(21,'YOSEMITE','Travis Scott',NULL,NULL,NULL,'POP'),(22,'Dior','Pop Smoke',NULL,NULL,NULL,'RAP'),(23,'Wasted','Tiesto',NULL,NULL,NULL,'EDM'),(24,'Beautiful Girls','Sean Kingston',NULL,NULL,NULL,'POP'),(25,'Time of Our Lives','Pit Bull','Ne-Yo',NULL,NULL,'POP'),(26,'Daylight','Joji','Diplo',NULL,NULL,'POP'),(27,'Wicked Games','The Weekend',NULL,NULL,NULL,'POP'),(28,'Paranoid','Post Malone',NULL,NULL,NULL,'POP'),(29,'From Time','Drake','Jhene Aiko',NULL,NULL,'RAP'),(30,'Chanel','Frank Ocean',NULL,NULL,NULL,'R&B'),(31,'100 Degrees','Rich Brian',NULL,NULL,NULL,'RAP'),(32,'Go To Town','Doja Cat',NULL,NULL,NULL,'POP'),(33,'It Wasn\'t Me','Shaggy','Rik Rok',NULL,NULL,'POP'),(34,'Claire De Lune','Claude Debussy',NULL,NULL,NULL,'CLASSICAL'),(35,'Are You Bored Yet?','Wallows','Clairo',NULL,NULL,'INDIE'),(36,'Stunnin\'','Curtis Waters','Harm Franklin',NULL,NULL,'POP'),(37,'Ballin\'','Mustard','Roddy Rich',NULL,NULL,'RAP'),(38,'Light','San Holo',NULL,NULL,25,'EDM'),(39,'Potions','SLANDER','Said the Sky, JT Roach',NULL,25,'EDM'),(40,'Runaway','Galantis',NULL,NULL,25,'EDM'),(41,'GUD VIBRATIONS','NGHTMRE','SLANDER',NULL,25,'EDM'),(42,'Fractures','ILLENIUM','Nevve',NULL,25,'EDM'),(43,'Blue Moon','Billie Holiday',NULL,NULL,NULL,'JAZZ'),(44,'Mirrors','Freddie Hubbard',NULL,NULL,NULL,'JAZZ'),(45,'Crashing','ILLENIUM',NULL,NULL,5,'EDM'),(46,'Love VIP','Subsonic',NULL,NULL,NULL,'EDM'),(47,'JEFE','Boombox Cartel',NULL,NULL,NULL,'EDM'),(48,'Call You Mine','The Chainsmokers','Bebe Rexha',NULL,NULL,'EDM'),(49,'Balenciaga','Cheat Codes',NULL,NULL,NULL,'EDM'),(50,'Back To U','SLANDER','William Black',NULL,NULL,'EDM'),(51,'All My Friends','MADEON',NULL,NULL,NULL,'EDM'),(52,'THE DROP','Gammer',NULL,NULL,NULL,'EDM'),(53,'You','Galantis',NULL,NULL,NULL,'EDM'),(54,'Throw It Up','Wooli',NULL,NULL,NULL,'EDM'),(55,'DJ Turn It Up','Yellow Claw',NULL,NULL,NULL,'EDM'),(56,'Sad Machine','Porter Robinson',NULL,NULL,NULL,'EDM'),(57,'Alone','Marshmello',NULL,NULL,NULL,'EDM'),(58,'Chasing Highs','ALMA',NULL,NULL,NULL,'EDM'),(59,'Up','Cardi B',NULL,NULL,NULL,'RAP'),(60,'Try Me','Lil Mosey',NULL,NULL,NULL,'RAP'),(61,'Epidemic','Polo G',NULL,NULL,NULL,'RAP'),(62,'On Me','Lil Baby',NULL,NULL,NULL,'RAP'),(63,'Tequila Shots','Kid Cudi',NULL,NULL,NULL,'RAP'),(64,'Everybody','Logic',NULL,NULL,NULL,'RAP'),(65,'Leaked','Lil TJay',NULL,NULL,NULL,'RAP'),(66,'Why Would I Stop?','Big Sean',NULL,NULL,NULL,'RAP'),(67,'Excu$e Me','A$AP Rocky',NULL,NULL,NULL,'RAP'),(68,'BOP','DABaby',NULL,NULL,NULL,'RAP'),(69,'20 Min','Lil Uzi Vert',NULL,NULL,NULL,'RAP'),(70,'KOD','J.Cole',NULL,NULL,NULL,'RAP'),(71,'VALENTINO','24KGolden',NULL,NULL,NULL,'RAP'),(72,'Deams and Nightmares','Meek Mill',NULL,NULL,NULL,'RAP'),(73,'Hot Girl','Meghan Thee Stallion',NULL,NULL,20,'POP'),(74,'Envy Me','Cowboy',NULL,NULL,NULL,'RAP'),(75,'Whats Poppin','Jack Harlow',NULL,NULL,NULL,'RAP'),(76,'Barbie Dreams','Niki Minaj',NULL,NULL,NULL,'RAP'),(78,'Hold On','Justin Bieber',NULL,NULL,NULL,'POP'),(79,'Manic','Conan Gray',NULL,NULL,NULL,'POP'),(80,'pov','Arianna Grande',NULL,NULL,NULL,'POP'),(81,'At My Worst','Pink Sweat$',NULL,NULL,NULL,'POP'),(82,'Crush','Souly Had',NULL,NULL,NULL,'POP'),(83,'Green Light','Marlhy',NULL,NULL,NULL,'POP'),(84,'Autopilot','Tiffany Day',NULL,NULL,NULL,'POP'),(85,'Glitter','BENEE',NULL,NULL,NULL,'POP'),(86,'Candy Paint ','Post Malone',NULL,NULL,NULL,'POP'),(87,'2002','Anne-Marie',NULL,NULL,NULL,'POP'),(88,'Why','Bazzi',NULL,NULL,NULL,'POP'),(89,'Imagine If','Gnash',NULL,NULL,NULL,'POP'),(90,'Hide away','Dya',NULL,NULL,NULL,'POP'),(91,'Summer On You','PRETTYMUCH',NULL,NULL,NULL,'POP'),(92,'No One Compares To You','Jack & Jack',NULL,NULL,NULL,'POP');
/*!40000 ALTER TABLE `songs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-27 22:13:28
